
CREATE PROCEDURE [dbo].[Dat_Hang]
    @CustomerID   INT,
    @VoucherCode  NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @CartID INT,
        @Subtotal money,
        @RankDiscountRate FLOAT = 0,
        @RankDiscount money = 0,
        @VoucherID INT = NULL,
        @VoucherDiscount money = 0,
        @TotalDue money,
        @SalesOrderID INT,
        @SalesOrderNumber NVARCHAR(25);

    BEGIN TRY
        BEGIN TRAN;

        -- 1) Giỏ chưa checkout
        SELECT TOP (1) @CartID = CartID
        FROM dbo.Cart
        WHERE CustomerID = @CustomerID AND IsCheckedOut = 0
        ORDER BY CartID DESC;

        IF @CartID IS NULL
            THROW 50000, N'Không có giỏ hàng để đặt.', 1;

        -- 2) Tổng tiền (nên dùng UnitPrice đã “chốt” trong CartItem)
        SELECT @Subtotal = SUM(ci.Quantity * ci.UnitPrice)
        FROM dbo.CartItem ci
        WHERE ci.CartID = @CartID;

        -- 3) Giảm theo rank
        SELECT @RankDiscountRate = ISNULL(discount,0)
        FROM dbo.RankCustomer
        WHERE CustomerID = @CustomerID;

        SET @RankDiscount = @Subtotal * @RankDiscountRate;

        -- 4) Voucher (nếu có)
        IF @VoucherCode IS NOT NULL AND LTRIM(RTRIM(@VoucherCode)) <> N''
        BEGIN
            SELECT @VoucherID = VoucherID
            FROM dbo.Voucher
            WHERE Code = @VoucherCode
              AND StartDate <= GETDATE()
              AND EndDate   >= GETDATE()
              AND ISNULL(Quantity,0) > 0
              AND Status = 1;

            IF @VoucherID IS NULL
                THROW 50001, N'Voucher không hợp lệ hoặc đã hết hạn/số lượng.', 1;

            IF EXISTS (SELECT 1 FROM dbo.VoucherUsage WHERE VoucherID=@VoucherID AND CustomerID=@CustomerID)
                THROW 50002, N'Khách hàng đã sử dụng voucher này.', 1;

            SELECT @VoucherDiscount =
                CASE 
                    WHEN DiscountPercent IS NOT NULL THEN @Subtotal * DiscountPercent/100.0
                    WHEN DiscountAmount  IS NOT NULL THEN DiscountAmount
                    ELSE 0 
                END
            FROM dbo.Voucher WHERE VoucherID=@VoucherID;
        END

        -- 5) Tổng tiền cuối
        SET @TotalDue = @Subtotal - @RankDiscount - @VoucherDiscount;
        IF @TotalDue < 0 SET @TotalDue = 0;

        -- 6) Sinh số đơn <= 25 ký tự
        -- dạng: SO + yyMMddHHmmss (12) + 6 số cuối CustomerID  => tối đa 20 ký tự
        SET @SalesOrderNumber =
            'SO' + FORMAT(GETDATE(),'yyMMddHHmmss') + RIGHT('000000'+CAST(@CustomerID AS VARCHAR(6)),6);

        -- 7) Insert SalesOrderHeader (TRUYỀN ĐỦ CÁC CỘT NOT NULL)
        INSERT INTO dbo.SalesOrderHeader
            (CustomerID, OrderDate, DueDate, ShipDate, Freight, SalesOrderNumber, TotalDue, ModifiedDate)
        VALUES
            (@CustomerID, GETDATE(), DATEADD(DAY,3,GETDATE()), NULL, 0, @SalesOrderNumber, @TotalDue, GETDATE());

        SET @SalesOrderID = SCOPE_IDENTITY();   -- lúc này chắc chắn có giá trị

        -- 8) Insert SalesOrderDetail
        INSERT INTO dbo.SalesOrderDetail (SalesOrderID, ProductID, OrderQty, UnitPrice)
        SELECT @SalesOrderID, ci.ProductID, ci.Quantity, ci.UnitPrice
        FROM dbo.CartItem ci
        WHERE ci.CartID = @CartID;

				-- 8.1) Trừ kho hàng theo nhiều kho
		DECLARE @Pid INT, @Qty INT, @Need INT;

		DECLARE cur CURSOR FOR
			SELECT ProductID, Quantity
			FROM dbo.CartItem
			WHERE CartID = @CartID;

		OPEN cur;
		FETCH NEXT FROM cur INTO @Pid, @Qty;

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @Need = @Qty;

			-- 1) Kiểm tra tổng tồn kho
			IF (
				SELECT SUM(CAST(Quantity AS INT))
				FROM dbo.ProductInventory
				WHERE ProductID = @Pid
			) < @Need
			BEGIN
				CLOSE cur;
				DEALLOCATE cur;
				THROW 50003, N'Không đủ hàng trong kho.', 1;
			END

			-- 2) Trừ kho: ưu tiên kho có nhiều hàng trước
			DECLARE invCur CURSOR FOR
				SELECT LocationID, CAST(Quantity AS INT) AS Qty
				FROM dbo.ProductInventory
				WHERE ProductID = @Pid
				ORDER BY Qty DESC;   -- trừ kho nhiều trước

			DECLARE @Loc INT, @Stock INT;
			OPEN invCur;
			FETCH NEXT FROM invCur INTO @Loc, @Stock;

			WHILE @@FETCH_STATUS = 0 AND @Need > 0
			BEGIN
				DECLARE @Take INT = CASE WHEN @Stock >= @Need THEN @Need ELSE @Stock END;

				UPDATE dbo.ProductInventory
				SET Quantity = Quantity - @Take,
					ModifiedDate = GETDATE()
				WHERE ProductID = @Pid AND LocationID = @Loc;

				SET @Need = @Need - @Take;

				FETCH NEXT FROM invCur INTO @Loc, @Stock;
			END

			CLOSE invCur;
			DEALLOCATE invCur;

			FETCH NEXT FROM cur INTO @Pid, @Qty;
		END

		CLOSE cur;
		DEALLOCATE cur;

        -- 9) Ghi nhận dùng voucher & trừ số lượng
        IF @VoucherID IS NOT NULL
        BEGIN
            INSERT INTO dbo.VoucherUsage (VoucherID, CustomerID, OrderID, UsedDate)
            VALUES (@VoucherID, @CustomerID, @SalesOrderID, GETDATE());

            UPDATE dbo.Voucher SET Quantity = Quantity - 1 WHERE VoucherID=@VoucherID;
        END

        -- 10) Đóng giỏ
        UPDATE dbo.Cart
        SET IsCheckedOut = 1, ModifiedDate = GETDATE()
        WHERE CartID = @CartID;

		

        COMMIT;
        SELECT N'Đặt hàng thành công' AS Message, @SalesOrderID AS SalesOrderID, @TotalDue AS TotalDue;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        ;THROW;
    END CATCH
END
go

