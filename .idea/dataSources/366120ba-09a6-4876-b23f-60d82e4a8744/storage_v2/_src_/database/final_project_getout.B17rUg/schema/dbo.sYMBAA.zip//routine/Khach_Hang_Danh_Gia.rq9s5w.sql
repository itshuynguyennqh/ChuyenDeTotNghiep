CREATE PROCEDURE Khach_Hang_Danh_Gia
    @ProductID INT,
    @ReviewerName NVARCHAR(50),
    @EmailAddress NVARCHAR(50),
    @Rating INT,
    @Comments NVARCHAR(3850)
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra sản phẩm có tồn tại không
    IF NOT EXISTS (SELECT 1 FROM Product WHERE ProductID = @ProductID)
    BEGIN
        RAISERROR(N'Sản phẩm không tồn tại.', 16, 1);
        RETURN;
    END;

    -- Kiểm tra rating hợp lệ
    IF (@Rating < 1 OR @Rating > 5)
    BEGIN
        RAISERROR(N'Điểm đánh giá phải nằm trong khoảng 1 đến 5.', 16, 1);
        RETURN;
    END;

    INSERT INTO ProductReview
        (ProductID, ReviewerName, ReviewDate, EmailAddress, Rating, Comments, ModifiedDate)
    VALUES
        (@ProductID, @ReviewerName, GETDATE(), @EmailAddress, @Rating, @Comments, GETDATE());

    SELECT 'Đánh giá đã được ghi nhận!' AS Message;
END;
go

