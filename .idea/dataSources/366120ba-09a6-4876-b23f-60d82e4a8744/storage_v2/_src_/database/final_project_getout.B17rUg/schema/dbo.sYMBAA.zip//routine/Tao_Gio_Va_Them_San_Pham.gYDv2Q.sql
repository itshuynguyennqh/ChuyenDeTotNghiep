CREATE PROCEDURE [dbo].[Tao_Gio_Va_Them_San_Pham]
    @CustomerID INT,
    @ProductID INT,
    @Quantity INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CartID INT;
    DECLARE @UnitPrice MONEY;

    -- ⚡ Lấy giá sản phẩm từ bảng Product
    SELECT @UnitPrice = StandardCost
    FROM Product
    WHERE ProductID = @ProductID;

    IF @UnitPrice IS NULL
    BEGIN
        RAISERROR(N'Sản phẩm không tồn tại hoặc chưa có giá.', 16, 1);
        RETURN;
    END;

    -- ⚡ Kiểm tra khách hàng đã có giỏ hàng chưa
    SELECT @CartID = CartID
    FROM Cart
    WHERE CustomerID = @CustomerID AND IsCheckedOut = 0;

    -- Nếu chưa có giỏ thì tạo giỏ mới
    IF @CartID IS NULL
    BEGIN
        INSERT INTO Cart (CustomerID, CreatedDate, ModifiedDate, Status, IsCheckedOut)
        VALUES (@CustomerID, GETDATE(), GETDATE(), 'Active', 0);

        SET @CartID = SCOPE_IDENTITY();
    END;

    -- ⚡ Kiểm tra sản phẩm đã có trong giỏ hay chưa
    IF EXISTS (SELECT 1 FROM CartItem WHERE CartID = @CartID AND ProductID = @ProductID)
    BEGIN
        UPDATE CartItem
        SET Quantity = Quantity + @Quantity,
            DateUpdated = GETDATE()
        WHERE CartID = @CartID AND ProductID = @ProductID;
    END
    ELSE
    BEGIN
        INSERT INTO CartItem (CartID, ProductID, Quantity, UnitPrice, DateAdded, DateUpdated)
        VALUES (@CartID, @ProductID, @Quantity, @UnitPrice, GETDATE(), GETDATE());
    END;

    SELECT 'Đã thêm sản phẩm vào giỏ hàng!' AS Message, @CartID AS CartID;
END;
go

