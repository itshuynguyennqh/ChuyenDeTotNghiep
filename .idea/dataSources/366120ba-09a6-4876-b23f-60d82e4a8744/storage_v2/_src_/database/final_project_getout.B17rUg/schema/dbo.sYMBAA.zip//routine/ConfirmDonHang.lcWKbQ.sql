CREATE PROCEDURE dbo.ConfirmDonHang
    @SalesOrderID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Now DATETIME = GETDATE();

    -- Cập nhật trạng thái và ShipDate
    UPDATE dbo.SalesOrderHeader
    SET 
        OrderStatus  = N'Confirm',
        ModifiedDate = @Now,
        ShipDate     = DATEADD(DAY, 2, @Now)   -- ngày giao hàng sau 2 ngày
    WHERE SalesOrderID = @SalesOrderID
      AND OrderStatus NOT IN (N'Complete', N'Cancelled');

    IF @@ROWCOUNT = 0
    BEGIN
        RAISERROR (N'Không thể xác nhận đơn. Đơn không tồn tại hoặc đã hoàn thành/hủy.', 16, 1);
        RETURN;
    END
END;
go

