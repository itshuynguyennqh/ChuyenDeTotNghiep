CREATE PROCEDURE RegisterCustomer
(
    @PhoneNumber NVARCHAR(25),
    @PasswordSalt VARCHAR(10),
    @AddressLine1 NVARCHAR(60),
    @PhoneNumberTypeID int 
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @NewCustomerID INT;

    -- 1) Tạo khách hàng mới (không cần tên, ModifiedDate tự GETDATE())
    INSERT INTO dbo.Customer DEFAULT VALUES;

    -- 2) Lấy ID vừa tạo
    SET @NewCustomerID = SCOPE_IDENTITY();

    -- 3) Thêm mật khẩu
    INSERT INTO dbo.CustomerPassWord (CustomerID, PasswordSalt)
    VALUES (@NewCustomerID, @PasswordSalt);

    -- 4) Thêm địa chỉ
    INSERT INTO dbo.CustomerAdress (CustomerID, AddressLine1)
    VALUES (@NewCustomerID, @AddressLine1);

    -- 5) Thêm số điện thoại (PhoneNumberTypeID = 1 là mặc định)
    INSERT INTO dbo.CustomerPhone (CustomerID, PhoneNumber, PhoneNumberTypeID)
    VALUES (@NewCustomerID, @PhoneNumber, @PhoneNumberTypeID);

    -- 6) Trả kết quả
    SELECT 'Đăng ký thành công!' AS Message, @NewCustomerID AS CustomerID;
END;
go

