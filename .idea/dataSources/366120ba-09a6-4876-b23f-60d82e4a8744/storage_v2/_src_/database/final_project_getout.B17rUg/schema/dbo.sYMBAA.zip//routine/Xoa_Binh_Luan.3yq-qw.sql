CREATE PROCEDURE Xoa_Binh_Luan
    @ProductReviewID INT,
    @StaffID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Chỉ nhân viên mới được xóa
    IF NOT EXISTS (SELECT 1 FROM [dbo].[employees] WHERE [BusinessEntityID] = @StaffID)
    BEGIN
        RAISERROR(N'Chỉ nhân viên mới có quyền xóa đánh giá!', 16, 1);
        RETURN;
    END;

    IF NOT EXISTS (SELECT 1 FROM ProductReview WHERE ProductReviewID = @ProductReviewID)
    BEGIN
        RAISERROR(N'Đánh giá không tồn tại.', 16, 1);
        RETURN;
    END;

    DELETE FROM ProductReview
    WHERE ProductReviewID = @ProductReviewID;

    SELECT N'🗑️ Đánh giá đã bị nhân viên xóa thành công!' AS Message;
END;
go

