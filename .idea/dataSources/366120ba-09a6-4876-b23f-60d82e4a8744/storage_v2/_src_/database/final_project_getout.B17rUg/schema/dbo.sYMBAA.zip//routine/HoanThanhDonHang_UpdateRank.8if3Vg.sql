CREATE PROCEDURE [dbo].[HoanThanhDonHang_UpdateRank]
    @SalesOrderID INT   -- ID đơn hàng khách đã nhận
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @CustomerID INT,
        @R INT,
        @F INT,
        @M DECIMAL(18,2),
        @LastDate DATETIME,
        @R_score INT = 1,
        @F_score INT = 1,
        @M_score INT = 1,
        @Final_score DECIMAL(15,2),
        @rank_cus NVARCHAR(20),
        @discount FLOAT;

    ------------------------------------------------------------
    -- 1. Lấy CustomerID từ SalesOrderID
    ------------------------------------------------------------
    SELECT @CustomerID = CustomerID
    FROM dbo.SalesOrderHeader
    WHERE SalesOrderID = @SalesOrderID;

    IF @CustomerID IS NULL
    BEGIN
        RAISERROR(N'Không tìm thấy đơn hàng hoặc đơn hàng không có CustomerID.', 16, 1);
        RETURN;
    END;

    ------------------------------------------------------------
    -- 2. Cập nhật trạng thái đơn hàng là Complete
    ------------------------------------------------------------
    UPDATE dbo.SalesOrderHeader
    SET OrderStatus  = N'Completed',
        ModifiedDate = GETDATE()
    WHERE SalesOrderID = @SalesOrderID;

    ------------------------------------------------------------
    -- 3. Tính lại RFM cho khách hàng này
    ------------------------------------------------------------

    -- R = số hóa đơn của khách này
    SELECT @R = COUNT(*) 
    FROM dbo.SalesOrderHeader
    WHERE CustomerID = @CustomerID;

    -- Lần mua gần nhất
    SELECT @LastDate = MAX(OrderDate)
    FROM dbo.SalesOrderHeader
    WHERE CustomerID = @CustomerID;

    -- F = số ngày từ lần mua gần nhất đến hôm nay
    SET @F = DATEDIFF(DAY, @LastDate, GETDATE());

    -- M = tổng tiền đã chi
    SELECT @M = SUM(TotalDue)
    FROM dbo.SalesOrderHeader
    WHERE CustomerID = @CustomerID;

    ------------------------------------------------------------
    -- 4. Chuẩn hóa điểm (R_score, F_score, M_score)
    ------------------------------------------------------------

    -- R_score phân theo phân vị số lượng đơn
    ;WITH RDist AS (
        SELECT CustomerID, 
               RANK() OVER (ORDER BY COUNT(*) ASC) AS rrank
        FROM dbo.SalesOrderHeader
        GROUP BY CustomerID
    )
    SELECT @R_score = CASE 
            WHEN rrank >= (SELECT 0.8 * COUNT(*) FROM RDist) THEN 5
            WHEN rrank >= (SELECT 0.6 * COUNT(*) FROM RDist) THEN 3
            WHEN rrank >= (SELECT 0.4 * COUNT(*) FROM RDist) THEN 2
            ELSE 1
        END
    FROM RDist 
    WHERE CustomerID = @CustomerID;

    -- F_score phân theo độ mới (ít ngày nhất = điểm cao)
    ;WITH FDist AS (
        SELECT CustomerID,
               RANK() OVER (
                   ORDER BY DATEDIFF(DAY, MAX(OrderDate), GETDATE()) ASC
               ) AS drank
        FROM dbo.SalesOrderHeader
        GROUP BY CustomerID
    )
    SELECT @F_score = CASE 
            WHEN drank <= (SELECT 0.2 * COUNT(*) FROM FDist) THEN 5
            WHEN drank <= (SELECT 0.4 * COUNT(*) FROM FDist) THEN 3
            WHEN drank <= (SELECT 0.6 * COUNT(*) FROM FDist) THEN 2
            ELSE 1
        END
    FROM FDist 
    WHERE CustomerID = @CustomerID;

    -- M_score phân theo tổng chi tiêu
    ;WITH MDist AS (
        SELECT CustomerID,
               RANK() OVER (ORDER BY SUM(TotalDue) ASC) AS mrank
        FROM dbo.SalesOrderHeader
        GROUP BY CustomerID
    )
    SELECT @M_score = CASE 
            WHEN mrank >= (SELECT 0.8 * COUNT(*) FROM MDist) THEN 5
            WHEN mrank >= (SELECT 0.6 * COUNT(*) FROM MDist) THEN 3
            WHEN mrank >= (SELECT 0.4 * COUNT(*) FROM MDist) THEN 2
            ELSE 1
        END
    FROM MDist 
    WHERE CustomerID = @CustomerID;

    ------------------------------------------------------------
    -- 5. Final_score + gán Rank + discount
    ------------------------------------------------------------
    SET @Final_score = (0.25 * @R_score + 0.25 * @F_score + 0.5 * @M_score);

    IF @Final_score >= 4
    BEGIN
        SET @rank_cus = N'Diamond';
        SET @discount = 0.3;
    END
    ELSE IF @Final_score >= 3 AND @Final_score < 4
    BEGIN
        SET @rank_cus = N'Gold';
        SET @discount = 0.1;
    END
    ELSE IF @Final_score >= 2 AND @Final_score < 3
    BEGIN
        SET @rank_cus = N'Silver';
        SET @discount = 0.0;
    END
    ELSE
    BEGIN
        SET @rank_cus = N'Bronze';
        SET @discount = 0.0;
    END;

    ------------------------------------------------------------
    -- 6. Lưu vào bảng RankCustomer (MERGE)
    ------------------------------------------------------------
    MERGE dbo.RankCustomer AS t
    USING (SELECT @CustomerID AS CustomerID) AS s
        ON t.CustomerID = s.CustomerID
    WHEN MATCHED THEN
        UPDATE SET 
            R           = @R, 
            F           = @F, 
            M           = @M, 
            Final_score = @Final_score, 
            rank_cus    = @rank_cus, 
            discount    = @discount
    WHEN NOT MATCHED THEN
        INSERT (CustomerID, R, F, M, Final_score, rank_cus, discount)
        VALUES (@CustomerID, @R, @F, @M, @Final_score, @rank_cus, @discount);

END;
go

