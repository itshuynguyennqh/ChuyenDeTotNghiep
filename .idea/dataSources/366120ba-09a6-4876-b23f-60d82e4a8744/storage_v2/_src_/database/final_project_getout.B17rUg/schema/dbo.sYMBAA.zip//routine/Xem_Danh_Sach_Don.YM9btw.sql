CREATE PROCEDURE Xem_Danh_Sach_Don
AS
SELECT SalesOrderID, CustomerID, OrderDate, TotalDue, OrderStatus
FROM SalesOrderHeader;
go

