
CREATE PROCEDURE [dbo].[Xoa_San_Pham]
    @ProductID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra tồn tại
    IF NOT EXISTS (SELECT 1 FROM Product WHERE ProductID = @ProductID)
    BEGIN
        RAISERROR(N'Sản phẩm không tồn tại!', 16, 1);
        RETURN;
    END;

    -- Ngừng bán sản phẩm (Soft Delete)
    UPDATE Product
    SET SellEndDate = GETDATE(),
        ModifiedDate = GETDATE()
    WHERE ProductID = @ProductID;

    SELECT N'✅ Sản phẩm đã được ngừng bán thành công!' AS Message;
END
go

