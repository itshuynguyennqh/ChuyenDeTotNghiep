CREATE PROCEDURE Sua_San_Pham
    @ProductID INT,
    @Name NVARCHAR(50),
    @ProductNumber NVARCHAR(25),
    @Color NVARCHAR(15) = NULL,
    @ListPrice MONEY,
    @Size NVARCHAR(5) = NULL,
	@StandardCost Money,
	@DaysToManufacture int,
    @ProductSubcategoryID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM Product WHERE ProductID = @ProductID)
    BEGIN
        RAISERROR(N'Sản phẩm không tồn tại!', 16, 1);
        RETURN;
    END;

    UPDATE Product
    SET Name = @Name,
        ProductNumber = @ProductNumber,
        Color = @Color,
        ListPrice = @ListPrice,
        Size = @Size,
		StandardCost=@StandardCost,
		DaysToManufacture=@DaysToManufacture,
        ProductSubcategoryID = @ProductSubcategoryID
    WHERE ProductID = @ProductID;

    SELECT N'✏ Sản phẩm đã được cập nhật!' AS Message;
END;
go

