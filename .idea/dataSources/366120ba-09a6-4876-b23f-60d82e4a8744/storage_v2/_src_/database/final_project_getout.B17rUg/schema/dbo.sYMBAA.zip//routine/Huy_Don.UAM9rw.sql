CREATE PROCEDURE Huy_Don
    @SalesOrderID INT
AS
BEGIN
    UPDATE SalesOrderHeader
    SET OrderStatus = 'Cancelled'
    WHERE SalesOrderID = @SalesOrderID;

    -- Hoàn lại kho
    UPDATE PI
    SET PI.Quantity = PI.Quantity + SD.OrderQty,
        PI.ModifiedDate = GETDATE()
    FROM ProductInventory PI
    JOIN SalesOrderDetail SD ON PI.ProductID = SD.ProductID
    WHERE SD.SalesOrderID = @SalesOrderID;
END
go

