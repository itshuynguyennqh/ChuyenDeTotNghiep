crEATE PROCEDURE ManageCustomerInfo
    @Action NVARCHAR(20),          -- ADD / UPDATE / DELETE
    @CustomerID INT,               -- Hệ thống truyền vào

    -- Thông tin tên
    @FirstName NVARCHAR(50) = NULL,
    @MiddleName NVARCHAR(50) = NULL,
    @LastName NVARCHAR(50) = NULL,

    -- Email
    @EmailAddressID INT = NULL,
    @EmailAddress NVARCHAR(50) = NULL,

    -- Phone
    @PhoneNumber NVARCHAR(25) = NULL,
    @OldPhoneNumber NVARCHAR(25) = NULL,

    -- Địa chỉ
    @AddressID INT = NULL,
    @AddressLine1 NVARCHAR(60) = NULL,
    @City NVARCHAR(30) = NULL,
    @PostalCode NVARCHAR(15) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -----------------------------------------------------
    -- 🟢 Cập nhật thông tin Họ tên
    -----------------------------------------------------
    IF @Action = 'UPDATE_NAME'
    BEGIN
        UPDATE Customer
        SET FirstName = ISNULL(@FirstName, FirstName),
            MiddleName = ISNULL(@MiddleName, MiddleName),
            LastName = ISNULL(@LastName, LastName)
        WHERE CustomerID = @CustomerID;

        RETURN;
    END

    -----------------------------------------------------
    -- 🟢 EMAIL
    -----------------------------------------------------
    IF @Action = 'ADD_EMAIL'
    BEGIN
        INSERT INTO CustomerEmailAddress (CustomerID, EmailAddress)
        VALUES (@CustomerID, @EmailAddress);
        RETURN;
    END

    IF @Action = 'UPDATE_EMAIL'
    BEGIN
        UPDATE CustomerEmailAddress
        SET EmailAddress = @EmailAddress
        WHERE EmailAddressID = @EmailAddressID AND CustomerID = @CustomerID;
        RETURN;
    END

    IF @Action = 'DELETE_EMAIL'
    BEGIN
        DELETE FROM CustomerEmailAddress
        WHERE EmailAddressID = @EmailAddressID AND CustomerID = @CustomerID;
        RETURN;
    END

    -----------------------------------------------------
    -- 🟢 SỐ ĐIỆN THOẠI
    -----------------------------------------------------
    IF @Action = 'ADD_PHONE'
    BEGIN
        INSERT INTO CustomerPhone (CustomerID, PhoneNumber)
        VALUES (@CustomerID, @PhoneNumber);
        RETURN;
    END

    IF @Action = 'UPDATE_PHONE'
    BEGIN
        UPDATE CustomerPhone
        SET PhoneNumber = @PhoneNumber
        WHERE CustomerID = @CustomerID AND PhoneNumber = @OldPhoneNumber;
        RETURN;
    END

    IF @Action = 'DELETE_PHONE'
    BEGIN
        DELETE FROM CustomerPhone
        WHERE CustomerID = @CustomerID AND PhoneNumber = @PhoneNumber;
        RETURN;
    END

    -----------------------------------------------------
    -- 🟢 ĐỊA CHỈ
    -----------------------------------------------------
    IF @Action = 'ADD_ADDRESS'
    BEGIN
        INSERT INTO CustomerAdress (CustomerID, AddressLine1, City, PostalCode)
        VALUES (@CustomerID, @AddressLine1, @City, @PostalCode);
        RETURN;
    END

    IF @Action = 'UPDATE_ADDRESS'
    BEGIN
        UPDATE CustomerAdress
        SET AddressLine1 = @AddressLine1,
            City = @City,
            PostalCode = @PostalCode
        WHERE AddressID = @AddressID AND CustomerID = @CustomerID;
        RETURN;
    END

    IF @Action = 'DELETE_ADDRESS'
    BEGIN
        DELETE FROM CustomerAdress
        WHERE AddressID = @AddressID AND CustomerID = @CustomerID;
        RETURN;
    END
END
go

