CREATE PROCEDURE Cap_Nhat_Trang_Thai_Don
    @SalesOrderID INT,
    @NewStatus NVARCHAR(20)
AS
UPDATE SalesOrderHeader
SET OrderStatus = @NewStatus, ModifiedDate = GETDATE()
WHERE SalesOrderID = @SalesOrderID;
go

