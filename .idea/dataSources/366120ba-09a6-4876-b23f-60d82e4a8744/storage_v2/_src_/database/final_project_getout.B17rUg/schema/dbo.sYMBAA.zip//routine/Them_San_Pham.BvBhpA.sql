CREATE PROCEDURE Them_San_Pham
    @Name NVARCHAR(50),
    @ProductNumber NVARCHAR(25),
    @Color NVARCHAR(15) = NULL,
    @ListPrice MONEY,
    @Size NVARCHAR(5) = NULL,
	@StandardCost Money,
	@DaysToManufacture int,
    @ProductSubcategoryID INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Product (Name, ProductNumber, Color, ListPrice, Size,StandardCost,[DaysToManufacture], ProductSubcategoryID)
    VALUES (@Name, @ProductNumber, @Color, @ListPrice, @Size,@StandardCost,@DaysToManufacture, @ProductSubcategoryID);

    SELECT SCOPE_IDENTITY() AS NewProductID, N'✅ Sản phẩm đã được thêm thành công!' AS Message;
END;
go

